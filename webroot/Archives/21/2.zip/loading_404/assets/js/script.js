
(function($){ 
"use strict";

/*========== Loader start ================*/
$(window).on('load', function() {
	$('#loader-wrapper').fadeIn();
	setTimeout(function() {
		$('#loader-wrapper').fadeOut();
	}, 500);
});
})(jQuery);