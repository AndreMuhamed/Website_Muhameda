jQuery(function($){
    $( '.g-recaptcha' ).attr( 'data-theme', 'dark' );
});